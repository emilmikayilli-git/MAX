@echo off
title MAX qurasdirma
cd /d "%~dp0"

python --version >nul 2>nul
if errorlevel 1 (
  echo Python tapilmadi, yuklenir...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  if errorlevel 1 start https://www.python.org/downloads/
  echo.
  echo Python qurasdirildiqdan sonra bu pencereni bagla ve install.bat faylini YENIDEN ac.
  echo ^(Python saytindan yuklesen, qurasdirarken "Add Python to PATH" xanasini isaretle.^)
  pause
  exit /b
)

echo Ses paketi qurasdirilir...
python -m pip install --quiet --upgrade edge-tts
if errorlevel 1 echo XEBERDARLIQ: edge-tts qurasdirilmadi. MAX yene isleyecek, amma ses sade olacaq.

rem Qurasdirma yeri yalniz ASCII olmalidir (istifadeci adinda xususi herf varsa Windows qisayolu yarada bilmir)
set "DEST=%LOCALAPPDATA%\MAX"
powershell -NoProfile -Command "if ($env:LOCALAPPDATA -match '[^\x00-\x7F]') { exit 1 }"
if errorlevel 1 set "DEST=%SystemDrive%\MAX"

rem kohne serveri bagla
taskkill /f /im pythonw.exe >nul 2>nul
taskkill /f /fi "WINDOWTITLE eq MAX server*" >nul 2>nul
for %%D in ("%LOCALAPPDATA%\MAX" "%SystemDrive%\MAX") do if exist "%%~D\max.pid" for /f "usebackq" %%P in ("%%~D\max.pid") do taskkill /f /pid %%P >nul 2>nul

if not exist "%DEST%" mkdir "%DEST%" >nul 2>nul
if not exist "%DEST%" set "DEST=%PUBLIC%\MAX"
if not exist "%DEST%" mkdir "%DEST%"

rem kohne yerden acari ve ayarlari kocur
if /i not "%DEST%"=="%LOCALAPPDATA%\MAX" if exist "%LOCALAPPDATA%\MAX\key.txt" if not exist "%DEST%\key.txt" copy /y "%LOCALAPPDATA%\MAX\key.txt" "%DEST%" >nul
if /i not "%DEST%"=="%LOCALAPPDATA%\MAX" if exist "%LOCALAPPDATA%\MAX\settings.json" if not exist "%DEST%\settings.json" copy /y "%LOCALAPPDATA%\MAX\settings.json" "%DEST%" >nul

set "KEY="
if exist "%DEST%\key.txt" goto haskey
echo.
set /p KEY=Gemini API acarini yapisdir ^(yalniz bir defe sorusulur^): 
:haskey

copy /y server.py "%DEST%" >nul
copy /y max.html "%DEST%" >nul
copy /y start.bat "%DEST%" >nul
copy /y MAX.vbs "%DEST%" >nul
if exist max.ico copy /y max.ico "%DEST%" >nul
if defined KEY >"%DEST%\key.txt" echo %KEY%
if /i not "%DEST%"=="%LOCALAPPDATA%\MAX" rmdir /s /q "%LOCALAPPDATA%\MAX" >nul 2>nul

del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\MAX.bat" "%USERPROFILE%\Desktop\MAX.bat" "%USERPROFILE%\OneDrive\Desktop\MAX.bat" >nul 2>nul
rem qisayol ASCII qovluqda yaradilir, sonra Desktop ve Startup-a kopyalanir
powershell -NoProfile -Command "$ErrorActionPreference='Stop'; $w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut('%DEST%\MAX.lnk'); $s.TargetPath=$env:WINDIR+'\System32\wscript.exe'; $s.Arguments='\"%DEST%\MAX.vbs\"'; $s.WorkingDirectory='%DEST%'; $s.IconLocation='%DEST%\max.ico'; $s.Description='MAX'; $s.Save(); foreach($d in 'Desktop','Startup'){ Copy-Item '%DEST%\MAX.lnk' ([Environment]::GetFolderPath($d)+'\MAX.lnk') -Force }"
if errorlevel 1 (
  echo.
  echo XEBERDARLIQ: ikon yaradila bilmedi. MAX-i "%DEST%\MAX.vbs" faylindan ace bilersen.
) else (
  echo.
  echo Hazirdir! Desktop-da MAX ikonu yarandi, kompyuter acilanda da ozu aciliib "Hello sir" diyecek.
)
echo Mikrofon icazesi sorusanda "Icaze ver" sec.
wscript "%DEST%\MAX.vbs"
pause
