@echo off
taskkill /f /im pythonw.exe >nul 2>nul
for %%D in ("%LOCALAPPDATA%\MAX" "%SystemDrive%\MAX" "%PUBLIC%\MAX") do if exist "%%~D\max.pid" for /f "usebackq" %%P in ("%%~D\max.pid") do taskkill /f /pid %%P >nul 2>nul
taskkill /f /fi "WINDOWTITLE eq MAX server*" >nul 2>nul
del "%USERPROFILE%\Desktop\MAX.bat" "%USERPROFILE%\OneDrive\Desktop\MAX.bat" "%USERPROFILE%\Desktop\MAX.lnk" "%USERPROFILE%\OneDrive\Desktop\MAX.lnk" >nul 2>nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\MAX.bat" "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\MAX.lnk" >nul 2>nul
rmdir /s /q "%LOCALAPPDATA%\MAX" >nul 2>nul
rmdir /s /q "%SystemDrive%\MAX" >nul 2>nul
rmdir /s /q "%PUBLIC%\MAX" >nul 2>nul
reg delete "HKCU\Environment" /v GEMINI_API_KEY /f >nul 2>nul
echo MAX silindi.
pause
