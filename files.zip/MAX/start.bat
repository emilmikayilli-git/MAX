@echo off
cd /d "%~dp0"
set "OLD="
if exist max.pid set /p OLD=<max.pid
if defined OLD taskkill /f /pid %OLD% >nul 2>nul
start "" /b python server.py
for /l %%i in (1,1,30) do (
  curl -s -o nul http://127.0.0.1:8765/health && goto up
  ping -n 2 127.0.0.1 >nul
)
:up
start "" msedge --app=http://localhost:8765 --user-data-dir="%~dp0profile" --autoplay-policy=no-user-gesture-required --window-size=1180,760
